/**
 * 
 */
/**
 * 
 */
module Snake {
	requires java.desktop;
	exports snakegame;
    
}